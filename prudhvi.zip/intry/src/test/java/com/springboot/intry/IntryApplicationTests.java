package com.springboot.intry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntryApplicationTests {

	@Test
	void contextLoads() {
	}

}
