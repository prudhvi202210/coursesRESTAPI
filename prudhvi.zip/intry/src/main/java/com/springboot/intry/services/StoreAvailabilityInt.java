package com.springboot.intry.services;

import java.util.List;

import com.springboot.intry.entities.StoreAvailability;

public interface StoreAvailabilityInt {

	List<StoreAvailability> storeAvail();
	
}
