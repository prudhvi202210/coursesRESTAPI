package com.springboot.intry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntryApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntryApplication.class, args);
	}

}
